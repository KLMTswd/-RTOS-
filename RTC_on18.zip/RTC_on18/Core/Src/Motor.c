#include "main.h"
#include "tim.h"

volatile uint8_t Making = 0;
uint8_t canReset = 0;
volatile uint16_t ct = 0;
volatile uint8_t goct = 0;        //允许我们的软件定时器开始计时我们的 Motor 时间

void Eadd(int speed)
{
		
  	if( speed  >= 0 )
		{	
				__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1,speed);
				__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2,0);
		}
		
		
		if( speed < 0 )
		{	
				__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_1,0);
				__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_2,-speed);
		}
}	

void Eshift(int speed)
{
		
  	if( speed  >= 0 )
		{	
				__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3,speed);
				__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4,0);
		}
		
		
		if( speed < 0 )
		{	
				__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_3,0);
				__HAL_TIM_SetCompare(&htim1, TIM_CHANNEL_4,-speed);
		}
}

void Eblendmove(int speed)
{
		
  	if( speed  >= 0 )
		{	
				__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3,speed);
				__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_4,0);
		}
		
		
		if( speed < 0 )
		{	
				__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_3,0);
				__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_4,-speed);
		}
}

void Eblender(int speed)     //由MOSET模块驱动的电路，故没有PWM和多条GPIO高低电平控制正反
{
		
  	if( speed  > 0 )
		{	
				HAL_GPIO_WritePin(Eblender_GPIO_Port,Eblender_Pin,GPIO_PIN_SET);
		}
		
		
		if( speed <= 0 )
		{	
				HAL_GPIO_WritePin(Eblender_GPIO_Port,Eblender_Pin,GPIO_PIN_RESET);
		}
}

void Emove(int speed)
{
		
  	if( speed  >= 0 )
		{	
				__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1,speed);
				__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2,0);
		}
		
		
		if( speed < 0 )
		{	
				__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_1,0);
				__HAL_TIM_SetCompare(&htim3, TIM_CHANNEL_2,-speed);
		}
}

void Ecatch(int speed)
{
		
  	if( speed  > 0 )
		{	
				HAL_GPIO_WritePin(Ecatch_P_GPIO_Port,Ecatch_P_Pin,GPIO_PIN_SET);
				HAL_GPIO_WritePin(Ecatch_N_GPIO_Port,Ecatch_N_Pin,GPIO_PIN_RESET);
		}
		
		
		if( speed <= 0 )  //马上停止，特性所致
		{	
				HAL_GPIO_WritePin(Ecatch_P_GPIO_Port,Ecatch_P_Pin,GPIO_PIN_RESET);
				HAL_GPIO_WritePin(Ecatch_N_GPIO_Port,Ecatch_N_Pin,GPIO_PIN_RESET);
		}
}

void Eloosen(int speed)
{
		
  	if( speed  >= 0 )
		{	
				HAL_GPIO_WritePin(Eloosen_P_GPIO_Port,Eloosen_P_Pin,GPIO_PIN_SET);
				HAL_GPIO_WritePin(Eloosen_N_GPIO_Port,Eloosen_N_Pin,GPIO_PIN_RESET);
		}
		
		
		if( speed < 0 )
		{	
				HAL_GPIO_WritePin(Eloosen_P_GPIO_Port,Eloosen_P_Pin,GPIO_PIN_RESET);
				HAL_GPIO_WritePin(Eloosen_N_GPIO_Port,Eloosen_N_Pin,GPIO_PIN_SET);
		}
}

void Ewater(int speed)
{
		
  	if( speed  > 0 )
		{	
				HAL_GPIO_WritePin(Ewater_GPIO_Port,Ewater_Pin,GPIO_PIN_SET);
		
		}
		
		
		if( speed <= 0 )
		{	
				HAL_GPIO_WritePin(Ewater_GPIO_Port,Ewater_Pin,GPIO_PIN_RESET);
		}
}



void Motor_Tick(void) //申请定时中断调用 1ms进入1次
{
	
		if( Making == 2 )
		{
				goct = 1;
				Eshift(-1750);
//				Eadd(1750);
//				Eblendmove(-1750);
				if(ct == 20)
				{
						goct = 0;
						ct = 0;
						Eshift(0);
						Eadd(0);
						Eblendmove(0);
					  canReset = 0;
						Making = 0;
				}	
		}	
	
		if(Making == 1 && canReset == 0)
		{	
				goct = 1;
				if(ct == 1)
				{	
						Ecatch(1);
						Eshift(-1750);
				}
				if(ct == 2)
				{
						Ecatch(0);
				}	
				
				if(ct == 40)
				{
						Eadd(1750);
				}	
				
				if(ct == 55)
				{
						Eshift(0);
				}	
				
				if(ct == 80)
				{
						Eshift(1750);						
				}	
				if(ct == 100)
				{
						Eadd(-1750);				
				}					
				
				if(ct == 165)
				{
						Eadd(0);
				}

				if(ct == 250)
				{
						Eshift(0);
						Ewater( 1 );  //全速流动
				}	
				if(ct == 280)
				{
						Ewater(0);
				}	
				if(ct == 300)
				{
						Eshift(1750);
				}
				
				if(ct == 329)
				{
						Eshift(0);
				}	
				
				if(ct == 330)
				{
						Eblendmove(1750);
				}	
				
				
				if(ct == 370)
				{
						Eblender( 1 );
				}	
				
				if(ct == 420)
				{
						Eblendmove(-1900);
				}
				
				if(ct == 450)
				{
						Eblender(0);
						Eshift(1750);
				}				
				
				if(ct == 500)
				{
						Eblendmove(0);
				}	
				
				if(ct == 560)
				{
						ct = 0;
						Eshift(0);
						Making = 0;
					  canReset = 1;
				}	
		}
		
		
}	

