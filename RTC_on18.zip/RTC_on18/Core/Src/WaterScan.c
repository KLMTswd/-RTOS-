#include "main.h"
#include "rtc.h"
#include "OLED.h"
#include "Buzzer.h"
#include "devRTC.h"
#include "GPIO.h"
#include "freertos.h"


typedef enum    //定义以后我们水位传感器感应到的各个阶段
{     
    STAGE_4,    // 800ml (S4监测)
    STAGE_3,    // 600ml (S3监测)
    STAGE_2,    // 400ml (S2监测)
    STAGE_1,    // 200ml (S1监测)
    STAGE_0,    // 完成饮水
    CUP_REMOVED // 空杯状态
} DrinkStage;

typedef struct
{
		DrinkStage currentStage;
		uint8_t isDrinkCompleted;    // 当前阶段喝水是否完成
		uint8_t isAlarmSet;					 // 闹钟已设置标记
		uint8_t isAlarmTriggered;    // 闹钟是否已触发

}SystemState;

volatile uint8_t test = 0;
volatile SystemState sysState = {STAGE_4, 0, 0};
volatile DrinkStage currentStage;
volatile DrinkStage prevStage = STAGE_4;
volatile uint16_t readyTime = 0;         // 备水计时
volatile uint16_t scanGap  =  0;         // 扫描间隔
volatile uint8_t tempState =  0;
volatile uint8_t readyWater = 0;
volatile uint32_t emptyTime = 0;
volatile uint8_t set_Alarmflag = 0;      // 标志位，0=可设闹钟，1=已设闹钟
volatile uint32_t cupRemovedTime = 0;    // 空杯计时
volatile uint8_t isNormallyCompleted = 0;
volatile uint8_t canLowPow = 0;
volatile uint8_t imLowPow = 0;  					//不能在低功耗的意思，一般出现在我们的超长闹钟启动，需要下一阶段的检测工作，未完成前这个时候就不能因为我外部按键的唤醒后又设个休眠 然后掉进睡眠模式了
volatile uint8_t allowScan = 0;

uint16_t Ti = 0;
uint8_t setUp;
uint8_t testAlarm = 0 ;
uint8_t WaterState;
uint8_t readyCup = 0;


uint8_t Water_GetData(void)
{
		uint8_t WaScanData;
		WaScanData = WaterState;
		return WaScanData ;
		
}

//void HAL_RTC_AlarmAEventCallback(RTC_HandleTypeDef *hrtc)
//{
//			SystemClock_Config();
//			OLED_Wake();
//			OLED_ShowString(4,1,"___Coming___"); 	
//			
//			sysState.isAlarmTriggered = 1; // 仅设置标志位，不直接改阶段
//			sysState.isAlarmSet = 1 ;
//			imLowPow = 1; 

//}


void WaScan_Tick(void) //申请定时中断调用 1ms进入1次
{
	
		uint8_t s1 = !HAL_GPIO_ReadPin(WaScan1_GPIO_Port,WaScan1_Pin);    //转化各个水位传感器
		uint8_t s2 = !HAL_GPIO_ReadPin(WaScan2_GPIO_Port,WaScan2_Pin);
		uint8_t s3 = !HAL_GPIO_ReadPin(WaScan3_GPIO_Port,WaScan3_Pin);
		uint8_t s4 = !HAL_GPIO_ReadPin(WaScan4_GPIO_Port,WaScan4_Pin);
	
	
		if( !readyWater && s1 && s2 && s3 && s4 )						 //硬性要求水满开启饮水时刻
		{
				readyWater = 1;
				readyCup = 0;
				BUZ_OFF();
		}	
		else if(!readyWater && !s4 )
		{
				tempState = 8;
				
				if( !readyCup )
				{
						readyTime =  HAL_GetTick();
						readyCup = 1;
				}
				
				if(HAL_GetTick() - readyTime > 5000)
				{
				    readyTime = 0;
						BUZ_Drop();
				}
	
				return;
				
		}
		
	  
		if(!s1 && !s2 && !s3 && !s4)         //空杯异常情况捕捉  
		{
				
				if(currentStage == STAGE_1 && sysState.isDrinkCompleted)					//最后的STAGE1喝完就是空杯状态，放过它了
				{	
						currentStage = STAGE_0;
						isNormallyCompleted = 1;
						BUZ_OFF();
				}	
				if(!isNormallyCompleted)
				{	
						tempState = 9;
					  if(currentStage != CUP_REMOVED)
				    {
						    prevStage = currentStage;
					      cupRemovedTime =  HAL_GetTick();
					      currentStage = CUP_REMOVED;
								
				    }	
						
						if(HAL_GetTick() - cupRemovedTime > 5000)                     // 5秒后仍为空杯则持续报警
			    	{
								cupRemovedTime =  HAL_GetTick();
					    	BUZ_Drop();
				    }	
				
				    return;        //立马推出这次WaScan函数，后面的swith-case全部不管 认定你是空杯，一个劲的叫
			  }
				

		}	
		
		 // 杯具放回处理
    if(currentStage == CUP_REMOVED) 
		{	 
				if(isNormallyCompleted)
				{
						currentStage = STAGE_0;
				}
				else
				{	
						currentStage = prevStage;
						HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
						cupRemovedTime =  HAL_GetTick();
        }
					
					// 不需要改变阶段，继续监测 倘若拿开5秒后又会再叫
    }

	
		if(allowScan == 1)					//时间间隔拉到2秒扫一次，修复因太快跳阶段的 bug
		{	
			allowScan = 0;
			switch(sysState.currentStage)
			{
				case STAGE_4:
					
					if(s4)
					{
							tempState = 4;      												// 为了OLED上显示这个阶段的东西
							BUZ_Drop();     													// 水未喝满 那我就开叫
							sysState.isDrinkCompleted = 0 ;
					}
					else
					{                                                               
							tempState = 4;
							HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);   // 标记已喝，等待闹钟
							sysState.isDrinkCompleted = 1 ;
						
							if(!sysState.isAlarmSet)
							{
									SetAlarm();
									sysState.isAlarmSet = 1 ;
									canLowPow = 1;
									imLowPow = 0;
							}	
							
							if(canLowPow == 1)
							{
											canLowPow = 0;
											OLED_Stop();
											OLED_Stop();
											BUZ_OFF();
											HAL_PWR_EnterSTOPMode(PWR_MAINREGULATOR_ON,PWR_STOPENTRY_WFI);   //进入核心低功耗模式
									
							}	
					}	
					
					if( sysState.isDrinkCompleted && AlarmTriggered )
					{
							sysState.currentStage = STAGE_3 ;
							sysState.isDrinkCompleted = 0 ;
							sysState.isAlarmSet = 0 ;
							AlarmTriggered = 0 ;
							sAlarm_flag=1 ;
					}	
					break;
					
				case STAGE_3:
					
					if(s3)
					{
							tempState = 3;
							BUZ_Drop();     //水未喝满 那我就开叫
							sysState.isDrinkCompleted = 0 ;
					}
					else
					{
							tempState = 3;
							HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);   //标记已喝，等待闹钟
							sysState.isDrinkCompleted = 1 ;
						
							if(!sysState.isAlarmSet)
							{
									SetAlarm();
									sysState.isAlarmSet = 1 ;
									canLowPow = 1;
									imLowPow = 0;
							}	
							
							if(canLowPow == 1)
							{
							
											canLowPow = 0;
											OLED_Stop();
											OLED_Stop();
											BUZ_OFF();
											HAL_PWR_EnterSTOPMode(PWR_MAINREGULATOR_ON,PWR_STOPENTRY_WFI);   //进入核心低功耗模式
					
							}								
							
					}	
					
					if( sysState.isDrinkCompleted && AlarmTriggered )
					{
							sysState.currentStage = STAGE_2 ;
							sysState.isDrinkCompleted = 0 ;
							sysState.isAlarmSet = 0 ;
							AlarmTriggered = 0 ;
							sAlarm_flag=1 ;
					}	
				break;
					
				case STAGE_2:
					if(s2)
					{
							tempState = 2;
							BUZ_Drop();    //水未喝满 那我就开叫
							sysState.isDrinkCompleted = 0 ;
					}
					else
					{
							tempState = 2;
							HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);   //标记已喝，等待闹钟
							sysState.isDrinkCompleted = 1 ;
						
							if(!sysState.isAlarmSet)
							{
									SetAlarm();
									sysState.isAlarmSet = 1 ;
									canLowPow = 1;
									imLowPow = 0;
							}	
							
							if(canLowPow == 1)
							{
							
											canLowPow = 0;
											OLED_Stop();
											OLED_Stop();
											BUZ_OFF();
											HAL_PWR_EnterSTOPMode(PWR_MAINREGULATOR_ON,PWR_STOPENTRY_WFI);   //进入核心低功耗模式
									
							}									
					}	
					
					if( sysState.isDrinkCompleted && AlarmTriggered )
					{
							sysState.currentStage = STAGE_1 ;
							sysState.isDrinkCompleted = 0 ;
							sysState.isAlarmSet = 0 ;
							AlarmTriggered = 0 ;
							sAlarm_flag=1 ;
					}	
				break;
					
				case STAGE_1:    //STAGE_1
					
					isNormallyCompleted = 1;
					if(s1)
					{
							tempState = 1;
							isNormallyCompleted = 1;
							BUZ_Drop();    //水未喝满 那我就开叫
							sysState.isDrinkCompleted = 0 ;
					}
					else
					{
							tempState = 1;
							HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);   //标记已喝，等待闹钟
							sysState.isDrinkCompleted = 1 ;
							if(!sysState.isAlarmSet)
							{
									SetAlarm();
									sysState.isAlarmSet = 1 ;
									canLowPow = 1;
									imLowPow = 0;
							}	
							
							if(canLowPow == 1)
							{
							
											canLowPow = 0;
											OLED_Stop();
											OLED_Stop();
											BUZ_OFF();
											HAL_PWR_EnterSTOPMode(PWR_MAINREGULATOR_ON,PWR_STOPENTRY_WFI);   //进入核心低功耗模式
									
							}		
					}	
					
					if( sysState.isDrinkCompleted && AlarmTriggered )
					{
							sysState.currentStage = STAGE_0 ;
							sysState.isDrinkCompleted = 0 ;
							sysState.isAlarmSet = 0 ;
							AlarmTriggered = 0 ;
							sAlarm_flag=1 ;
					}							

				break;
					
				case STAGE_0:
							tempState = 0;
							HAL_GPIO_WritePin(BUZZER_GPIO_Port, BUZZER_Pin, GPIO_PIN_RESET);
				break;	
				
				case CUP_REMOVED:
					
				break;	
			}	
		
		}
}	


