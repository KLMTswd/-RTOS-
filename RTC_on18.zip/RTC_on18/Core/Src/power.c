#include "main.h"
#include "gpio.h"
#include <stdio.h>
#include "OLED.h"
#include "tim.h"
#include "WaterScan.h"
#include "Motor.h"

volatile uint8_t reLowPow = 0;     //重新回到我们的低功耗，也就是用在我们已经靠外部按键的唤醒之后为了继续省电的一个操作变量
volatile uint8_t PowControl = 0;
volatile uint16_t cnt = 0;
volatile uint8_t gocnt = 0;        //允许我们的软件定时器开始计时我们的唤醒显示时间

void Pow_Tick(void) //申请定时中断调用 1ms进入1次
{
	
		if( imLowPow == 0 && reLowPow == 1 && Making == 0)
		{	
			gocnt = 1;
			if(cnt >= 2)
			{
					cnt = 0;
			    reLowPow = 0;
					OLED_Stop();
					OLED_Stop();
//			  LED1_OFF();
					HAL_PWR_EnterSTOPMode(PWR_MAINREGULATOR_ON,PWR_STOPENTRY_WFI); //
			}
		}		
}	

void Check_PowerControl(void)
{
		if(PowControl == 1)
		{
				HAL_GPIO_WritePin(PowerControl_GPIO_Port,PowerControl_Pin,GPIO_PIN_SET);
			
		}	
		else
		{
				HAL_GPIO_WritePin(PowerControl_GPIO_Port,PowerControl_Pin,GPIO_PIN_RESET);	
		}
}	

