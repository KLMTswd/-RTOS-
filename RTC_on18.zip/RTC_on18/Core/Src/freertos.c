/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * File Name          : freertos.c
  * Description        : Code for freertos applications
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "key.h"
#include "tim.h"
#include "rtc.h"
#include "OLED.h"
#include "rtc.h"
#include "Motor.h"
#include "Power.h"
#include "Buzzer.h"
#include "devRTC.h"
#include "WaterScan.h"
#include "FreeRTOSConfig.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

	uint16_t i;
	 
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
			
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{		
		
		SystemClock_Config();
		OLED_Wake();
//		OLED_ShowString(4,7,"Get");
		reLowPow = 1;
	
}

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* USER CODE END Variables */
/* Definitions for OLEDshow */
osThreadId_t OLEDshowHandle;
const osThreadAttr_t OLEDshow_attributes = {
  .name = "OLEDshow",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for KeyScan */
osThreadId_t KeyScanHandle;
const osThreadAttr_t KeyScan_attributes = {
  .name = "KeyScan",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for PowTick */
osThreadId_t PowTickHandle;
const osThreadAttr_t PowTick_attributes = {
  .name = "PowTick",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for MotorTick */
osThreadId_t MotorTickHandle;
const osThreadAttr_t MotorTick_attributes = {
  .name = "MotorTick",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for WaScanTick */
osThreadId_t WaScanTickHandle;
const osThreadAttr_t WaScanTick_attributes = {
  .name = "WaScanTick",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityBelowNormal,
};
/* Definitions for BuzzerTick */
osThreadId_t BuzzerTickHandle;
const osThreadAttr_t BuzzerTick_attributes = {
  .name = "BuzzerTick",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityLow,
};
/* Definitions for myTimer01 */
osTimerId_t myTimer01Handle;
const osTimerAttr_t myTimer01_attributes = {
  .name = "myTimer01"
};
/* Definitions for myTimer02 */
osTimerId_t myTimer02Handle;
const osTimerAttr_t myTimer02_attributes = {
  .name = "myTimer02"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void vTaskOLEDshow(void *argument);
void vTaskKeyScan(void *argument);
void vTaskPowTick(void *argument);
void vTaskMotorTick(void *argument);
void vTaskWaScanTick(void *argument);
void vTaskBuzzerTick(void *argument);
void Callback01(void *argument);
void Callback02(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* Create the timer(s) */
  /* creation of myTimer01 */
  myTimer01Handle = osTimerNew(Callback01, osTimerPeriodic, NULL, &myTimer01_attributes);

  /* creation of myTimer02 */
  myTimer02Handle = osTimerNew(Callback02, osTimerPeriodic, NULL, &myTimer02_attributes);

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
	osTimerStart(myTimer01Handle,2000); 
	osTimerStart(myTimer02Handle,100);
	
	
	
  /* USER CODE END RTOS_TIMERS */

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of OLEDshow */
  OLEDshowHandle = osThreadNew(vTaskOLEDshow, NULL, &OLEDshow_attributes);

  /* creation of KeyScan */
  KeyScanHandle = osThreadNew(vTaskKeyScan, NULL, &KeyScan_attributes);

  /* creation of PowTick */
  PowTickHandle = osThreadNew(vTaskPowTick, NULL, &PowTick_attributes);

  /* creation of MotorTick */
  MotorTickHandle = osThreadNew(vTaskMotorTick, NULL, &MotorTick_attributes);

  /* creation of WaScanTick */
  WaScanTickHandle = osThreadNew(vTaskWaScanTick, NULL, &WaScanTick_attributes);

  /* creation of BuzzerTick */
  BuzzerTickHandle = osThreadNew(vTaskBuzzerTick, NULL, &BuzzerTick_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_vTaskOLEDshow */
/**
  * @brief  Function implementing the OLEDshow thread.
  * @param  argument: Not used
  * @retval None
  */
/* USER CODE END Header_vTaskOLEDshow */
void vTaskOLEDshow(void *argument)
{
  /* USER CODE BEGIN vTaskOLEDshow */
	OLED_Init();
	OLED_Clear();
	OLED_ShowString(1,1,"Mode:WaterScan");
	OLED_ShowString(2,1,"STAGE:");	
	OLED_ShowString(3,1,"Alarm:");
  /* Infinite loop */
  for(;;)
  {
		
		 if(test == 1)
		 {
				OLED_ShowSignedNum(4, 6,  i++, 5);
				test = 0;
		 }	
		 if(Key_Num == 1)
		 {		
				 Emove(0);
				 Making = 1;
				 PowControl = 1;
				 Key_Num = 0;
		 }	
	
		 if(Key_Num == 2)
		 {		
//				 Ewater( 1 );
				 HAL_GPIO_WritePin(BUZZER_GPIO_Port,BUZZER_Pin,GPIO_PIN_RESET);
				 Key_Num = 0;
		 }			
		
		 if(Key_Num == 3)
		 {		
//				 Ecatch( 1 );
				 Making = 2;
				 test = 1;
//			   HAL_GPIO_WritePin(BUZZER_GPIO_Port,BUZZER_Pin,GPIO_PIN_SET);
				 PowControl = 0;
				 Key_Num = 0;
	   }			
		
		 DisplayCountdown();
		
		 if(tempState == 9)
		 {
				OLED_ShowString(2,7,"Empty cup");
		 }	 
		 
		 if(tempState == 8)
		 {
				OLED_ShowString(2,7,"No Full  ");
		 }	
		 if(tempState == 4)
		 {
				OLED_ShowString(2,7,"800mL    ");
		 }		
		 if(tempState == 3)
		 {
				OLED_ShowString(2,7,"600mL    ");
		 }
		 if(tempState == 2)
		 {
				OLED_ShowString(2,7,"400mL    ");
		 }		 
		 if(tempState == 1)
		 {
				OLED_ShowString(2,7,"200mL    ");
		 }		 
		 if(tempState == 0)
		 {
				OLED_ShowString(2,7,"Success! ");
		 }		 
		 		
		
	   OLED_ShowSignedNum(3, 7,  remainingHour, 2);
		 OLED_ShowSignedNum(3, 10, remainingMin , 2);
		 OLED_ShowSignedNum(3, 13, remainingSec , 2);		
		
		
		
		
    osDelay(2);
  }
  /* USER CODE END vTaskOLEDshow */
}

/* USER CODE BEGIN Header_vTaskKeyScan */
/**
* @brief Function implementing the KeyScan thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_vTaskKeyScan */
void vTaskKeyScan(void *argument)
{
  /* USER CODE BEGIN vTaskKeyScan */
  /* Infinite loop */
  for(;;)
  {
		  static uint8_t count;
		  static uint8_t CurrState,PrevState;			
			
			count++;
			PrevState = CurrState;         // 存个�?  按下等于各个按键该有的�?�，松手�?0
			CurrState = Key_GetState();		
			
				if( CurrState == 0 && PrevState != 0 )
				{
						Key_Num = PrevState ;
				
				}			
		
			osDelay(10);
  }
  /* USER CODE END vTaskKeyScan */
}

/* USER CODE BEGIN Header_vTaskPowTick */
/**
* @brief Function implementing the PowTick thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_vTaskPowTick */
void vTaskPowTick(void *argument)
{
  /* USER CODE BEGIN vTaskPowTick */
  /* Infinite loop */
  for(;;)
  {
			Pow_Tick();
			Check_PowerControl();
  }
  /* USER CODE END vTaskPowTick */
}

/* USER CODE BEGIN Header_vTaskMotorTick */
/**
* @brief Function implementing the MotorTick thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_vTaskMotorTick */
void vTaskMotorTick(void *argument)
{
  /* USER CODE BEGIN vTaskMotorTick */
	
	HAL_TIM_PWM_Init(&htim1);
	HAL_TIM_PWM_Init(&htim3);
	HAL_TIM_PWM_Init(&htim4);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim1,TIM_CHANNEL_4);
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_2);
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_3);
	HAL_TIM_PWM_Start(&htim3,TIM_CHANNEL_4);	
	HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_1);
	HAL_TIM_PWM_Start(&htim4,TIM_CHANNEL_2);
	
	
  /* Infinite loop */
  for(;;)
  {
		Motor_Tick();
    osDelay(1);
  }
  /* USER CODE END vTaskMotorTick */
}

/* USER CODE BEGIN Header_vTaskWaScanTick */
/**
* @brief Function implementing the WaScanTick thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_vTaskWaScanTick */
void vTaskWaScanTick(void *argument)
{
  /* USER CODE BEGIN vTaskWaScanTick */
  /* Infinite loop */
  for(;;)
  {
		WaScan_Tick();
    osDelay(1);
  }
  /* USER CODE END vTaskWaScanTick */
}

/* USER CODE BEGIN Header_vTaskBuzzerTick */
/**
* @brief Function implementing the BuzzerTick thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_vTaskBuzzerTick */
void vTaskBuzzerTick(void *argument)
{
  /* USER CODE BEGIN vTaskBuzzerTick */
  /* Infinite loop */
  for(;;)
  {
		BUZ_Tick();
    osDelay(1);
  }
  /* USER CODE END vTaskBuzzerTick */
}

/* Callback01 function */
void Callback01(void *argument)
{
  /* USER CODE BEGIN Callback01 */
		
		allowScan = 1;
	
		if( gocnt == 1 )
		{	
				cnt++ ;
		}
		
		
  /* USER CODE END Callback01 */
}

/* Callback02 function */
void Callback02(void *argument)
{
  /* USER CODE BEGIN Callback02 */
	
		if( goct == 1 )
		{	
				ct++;     //专门用来给Motor.c计数
		}	
		
		if( BUZ_Gocnt == 1 )
		{	
				test = 1;
				BUZ_count++;     //专门用来给 BUZZER.c 计数的
		}			
		
  /* USER CODE END Callback02 */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */

