#ifndef __WATERSCAN_H__
#define __WATERSCAN_H__

#include "main.h"

extern volatile uint8_t imLowPow; 

uint8_t Water_GetData(void);
uint8_t Water_GetState(void);
void WaScan_Tick(void);

extern uint8_t tempState;
extern volatile uint8_t imLowPow;
extern volatile uint8_t test ;
extern volatile uint16_t readyTime;         // 备水计时
extern volatile uint8_t allowScan;

#endif

