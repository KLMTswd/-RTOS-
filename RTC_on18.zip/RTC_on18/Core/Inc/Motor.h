#ifndef __MOTOR_H__
#define __MOTOR_H__

#include "main.h"

void Eadd(int speed);
void Eshift(int speed);
void Eblendmove(int speed);
void Eblender(int speed);
void Emove(int speed);
void Ewater(int speed);
void Ecatch(int speed);
void Motor_Tick(void);

extern volatile uint8_t Making;
extern volatile uint16_t ct;
extern volatile uint8_t goct;

#endif

