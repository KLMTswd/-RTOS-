#ifndef __POWER_H__
#define __POWER_H__

#include "main.h"

void Pow_Tick(void);
void Check_PowerControl(void);

extern volatile uint8_t reLowPow ;
extern volatile uint8_t PowControl ;
extern volatile uint16_t cnt ;
extern volatile uint8_t gocnt ; 

#endif

