#ifndef __BUZZER_H
#define __BUZZER_H

#include "main.h"

void BUZ_OFF(void);
void BUZ_Drop(void);
void BUZ_Tick(void);

extern volatile uint8_t BUZ_Gocnt;
extern volatile uint16_t BUZ_count ;

#endif
